/*****************************************************************************************************************
#################################################################################################################
#     Date     #   version   #      Author      #                   Comments 
#---------------------------------------------------------------------------------------------------------------- 
#  12/08/2016  #   1.0.0.1   # Remi G Grandsire # Original version 
#################################################################################################################
*****************************************************************************************************************/

-- Make sure the correct database is selected prior to running this script

-- Adding Columns to Asset table

ALTER TABLE Asset
ADD UDFChar11 VARCHAR(75) NULL
   ,UDFChar12 VARCHAR(75) NULL
   ,UDFChar13 VARCHAR(75) NULL
   ,UDFChar14 VARCHAR(75) NULL
   ,UDFChar15 VARCHAR(75) NULL
   ,UDFChar16 VARCHAR(75) NULL
   ,UDFChar17 VARCHAR(75) NULL
   ,UDFChar18 VARCHAR(75) NULL
   ,UDFChar19 VARCHAR(75) NULL
   ,UDFChar20 VARCHAR(75) NULL
   ,UDFChar21 VARCHAR(75) NULL
   ,UDFChar22 VARCHAR(75) NULL
   ,UDFChar23 VARCHAR(75) NULL
   ,UDFChar24 VARCHAR(75) NULL
   ,UDFChar25 VARCHAR(75) NULL
   ,UDFChar26 VARCHAR(75) NULL
   ,UDFChar27 VARCHAR(75) NULL
   ,UDFChar28 VARCHAR(75) NULL
   ,UDFChar29 VARCHAR(75) NULL
   ,UDFChar30 VARCHAR(75) NULL
   ,UDFChar31 VARCHAR(75) NULL
   ,UDFChar32 VARCHAR(75) NULL
   ,UDFChar33 VARCHAR(75) NULL
   ,UDFChar34 VARCHAR(75) NULL
   ,UDFChar35 VARCHAR(75) NULL
   ,UDFChar36 VARCHAR(75) NULL
   ,UDFChar37 VARCHAR(75) NULL
   ,UDFChar38 VARCHAR(75) NULL
   ,UDFChar39 VARCHAR(75) NULL
   ,UDFChar40 VARCHAR(75) NULL
   ,UDFChar41 VARCHAR(75) NULL
   ,UDFChar42 VARCHAR(75) NULL
   ,UDFChar43 VARCHAR(75) NULL
   ,UDFChar44 VARCHAR(75) NULL
   ,UDFChar45 VARCHAR(75) NULL
   ,UDFChar46 VARCHAR(75) NULL
   ,UDFChar47 VARCHAR(75) NULL
   ,UDFChar48 VARCHAR(75) NULL
   ,UDFChar49 VARCHAR(75) NULL
   ,UDFChar50 VARCHAR(75) NULL
   ,UDFChar51 VARCHAR(75) NULL
   ,UDFChar52 VARCHAR(75) NULL;


-- Complete